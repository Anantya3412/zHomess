zHomes 1.0.2

Requirements:
- Paper 1.21.11 (or compatible Paper 1.21.x server)
- Java 21

Commands:
- /home <name> - teleport to a saved home; /home opens the main GUI.
- /homes - open the main GUI.
- /homes create - create the next available numbered home (1, 2, 3...).
- /homes <name> - teleport to a saved home.
- /sethome [name] - create or update a named home.
- /delhome <name> - delete a home.
- /zhomes reload - reload configuration (admin).

GUI:
- Main menu: Lapis Lazuli opens the saved-homes selector; White Banner creates the next numbered home.
- Saved-homes selector: Blue Bed = saved home (left-click teleport, right-click manage); Red Bed = create next numbered home; Gray Bed = locked slot.
- Home management includes teleport, rename, information, delete confirmation, and back navigation.

Tab completion:
- /home suggests saved home names.
- /homes suggests create and saved home names.

Default home limit is 5. Configure limits and GUI slots in config.yml.
Homes are stored in plugins/zHomes/homes.yml.
