@echo off
cd /d "%~dp0"
echo Building zHomes...
mvn clean package
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Make sure Java 21 and Maven 3.9+ are installed and on PATH.
  pause
  exit /b 1
)
echo.
echo SUCCESS! JAR: target\zHomes-1.0.0.jar
pause
