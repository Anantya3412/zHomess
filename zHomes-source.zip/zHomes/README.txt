zHomes 1.0.6

Build requirements:
- Java 21
- Maven 3.9+
- Paper API 1.21.11

Build:
  mvn clean package

The plugin JAR is created in target/.

GUI behavior:
- /homes opens the main menu.
- Homes (Lapis Lazuli) opens the saved-homes selector.
- Settings is placed farther to the right for a balanced layout.
- The saved-homes selector displays saved homes as blue beds, available slots as red beds,
  and slots beyond the player's configured limit as grey beds.
- Clicking a red bed creates the next numbered home at the player's current location.
  The newly created home is highlighted with a green bed and enchantment glint.
- Left-clicking a saved blue bed teleports; right-clicking opens its management menu.
- The Back arrow returns to the main menu.

Home limits are configurable in config.yml:
  homes:
    default-limit: 5
    permission-limits:
      zhomes.limit.10: 10
      zhomes.limit.25: 25

Players with zhomes.limit.unlimited have no configured limit. Use /zhomes reload after
editing config.yml. Existing homes are stored in plugins/zHomes/homes.yml.


HOME LIMIT PERMISSIONS (v1.0.6)
Default limit is configured with homes.default-limit in config.yml.
Available permission nodes: zhomes.limit.4, .5, .6, .7, .8, .9, .10, .15, .20, .25, .30, .50, .100.
For unlimited homes, use zhomes.limit.unlimited (operator by default).
If multiple numeric limit permissions are assigned, the highest limit takes priority.
