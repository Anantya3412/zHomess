zHomes 1.0.0 — Paper homes plugin
=================================

WHAT IS INCLUDED
- /sethome [name], /home [name], /delhome <name>, /homes
- 54-slot DonutSMP-inspired Homes GUI with blue saved-home beds, red create-home bed and grey glass background
- Right-click a saved bed to open its management GUI
- Management buttons: teleport, rename, icon placeholder, information, delete and back
- Home limits configurable by permission
- YAML storage in plugins/zHomes/homes.yml
- Configurable GUI title, slots, materials and messages

REQUIREMENTS
- Paper 1.21.11 (or compatible Paper 1.21.x build)
- Java 21
- Maven 3.9+ to build the JAR from source

BUILD (NO JAVA CODING REQUIRED)
1. Install Java 21 and Apache Maven 3.9+ on your computer.
2. Open this zHomes folder.
3. Double-click build.bat (or run: mvn clean package).
4. The plugin JAR will be created in target/zHomes-1.0.0.jar.
5. Put that JAR in your server's plugins folder and restart the server.

COMMANDS
/sethome [name]  Save your current location. If name is omitted, uses "home".
/home [name]     Teleport to a home, or open the GUI if no name is supplied.
/delhome <name>  Delete a home.
/homes           Open the homes GUI.
/zhomes reload   Reload config.yml (requires zhomes.admin).

PERMISSIONS
zhomes.use         Basic use (default true)
zhomes.admin       Reload configuration (default op)
zhomes.limit.5     Sets limit to 5 (default false)
zhomes.limit.10    Sets limit to 10 (default false)

NOTES
- The GUI is a functional implementation inspired by the supplied DonutSMP-style reference; it is not affiliated with or copied from DonutSMP.
- The Change Icon control is currently a visual placeholder; custom per-home icon persistence is not implemented in this first build.
- Delete currently deletes immediately after clicking the delete button; a separate confirmation screen is not included yet.
- This package is source code, not a precompiled JAR. Build it with Maven using build.bat.
