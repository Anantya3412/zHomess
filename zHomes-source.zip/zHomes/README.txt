zHomes 1.0.1 — Paper homes plugin
=================================

FIXES IN THIS VERSION
- Every configured home slot is now a bed, not a glass pane.
- Blue bed = an existing saved home.
- Red bed = an available slot; left-click it and enter a name in chat to create a home.
- Grey bed = a locked slot because the player's home limit has been reached.
- Left-click a saved blue bed to teleport.
- Right-click a saved blue bed to open Manage Home.
- Manage Home includes teleport, rename, info, delete confirmation, and back.
- Default home limit raised to 5. Permission limits: 10 and 25; ops can have unlimited with zhomes.limit.unlimited.
- Uses slot-to-home tracking rather than reading the bed's display name, preventing name parsing errors.

REQUIREMENTS
- Paper 1.21.11 / compatible Paper 1.21.x server
- Java 21
- Maven 3.9+ to build locally, or use the included GitHub Actions workflow.

BUILD LOCALLY
mvn clean package
Output: target/zHomes-1.0.1.jar

COMMANDS
/sethome [name]
/home [name]
/delhome <name>
/homes
/zhomes reload

NOTES
- This is source code, not a precompiled JAR.
- Custom home icon storage is not implemented yet; the management menu currently shows an explanatory message for that option.
- Test on a staging server and keep a backup of plugins/zHomes/homes.yml before replacing an existing plugin build.
