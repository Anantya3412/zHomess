package com.zhomes;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ZHomes extends JavaPlugin implements Listener {
    private final Map<UUID, Map<String, Location>> homes = new HashMap<>();
    private final Map<UUID, PendingInput> pending = new ConcurrentHashMap<>();
    private File homesFile;
    private YamlConfiguration homesYaml;
    private File settingsFile;
    private YamlConfiguration settingsYaml;
    private final Set<UUID> confirmTeleport = new HashSet<>();
    private final Map<UUID, Long> teleportCooldowns = new ConcurrentHashMap<>();
    private final Set<UUID> pendingTeleports = ConcurrentHashMap.newKeySet();
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        homesFile = new File(getDataFolder(), "homes.yml");
        if (!homesFile.exists()) {
            getDataFolder().mkdirs();
            try { homesFile.createNewFile(); }
            catch (IOException ex) { getLogger().severe("Could not create homes.yml: " + ex.getMessage()); }
        }
        loadHomes();
        loadSettings();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("home")).setExecutor(this::homeCommand);
        Objects.requireNonNull(getCommand("home")).setTabCompleter((sender, command, alias, args) -> {
            if (!(sender instanceof Player p) || args.length != 1) return List.of();
            String prefix = args[0].toLowerCase(Locale.ROOT);
            return homes.getOrDefault(p.getUniqueId(), Map.of()).keySet().stream()
                .filter(name -> name.startsWith(prefix)).sorted().toList();
        });
        Objects.requireNonNull(getCommand("sethome")).setExecutor(this::setHomeCommand);
        Objects.requireNonNull(getCommand("delhome")).setExecutor(this::deleteHomeCommand);
        Objects.requireNonNull(getCommand("homes")).setExecutor(this::homesCommand);
        Objects.requireNonNull(getCommand("homes")).setTabCompleter((sender, command, alias, args) -> {
            if (!(sender instanceof Player p)) return List.of();
            Map<String, Location> playerHomes = homes.getOrDefault(p.getUniqueId(), Map.of());
            if (args.length == 1) {
                String prefix = args[0].toLowerCase(Locale.ROOT);
                List<String> suggestions = new ArrayList<>();
                for (String option : List.of("create", "list", "settings", "teleport", "help", "info"))
                    if (option.startsWith(prefix)) suggestions.add(option);
                return suggestions;
            }
            return List.of();
        });
        Objects.requireNonNull(getCommand("zhomes")).setExecutor(this::adminCommand);
        getLogger().info("zHomes enabled. Default home limit: " + getConfig().getInt("homes.default-limit", 5));
    }

    @Override public void onDisable() { saveHomes(); }

    private boolean setHomeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (!p.hasPermission("zhomes.use")) { msg(p, "no-permission"); return true; }
        String name = cleanName(args.length == 0 ? "home" : args[0]);
        if (name == null) { p.sendMessage(text("§cUse 1-24 letters, numbers, _ or -.")); return true; }
        Map<String, Location> map = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        if (!map.containsKey(name) && map.size() >= limit(p)) { msg(p, "limit"); return true; }
        map.put(name, p.getLocation().clone());
        saveHomes(); msgHome(p, "set", name); return true;
    }

    private boolean homeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) {
            openHomes(p);
        } else if (args[0].equalsIgnoreCase("create")) {
            createHome(p, args.length >= 2 ? args[1] : null);
        } else {
            teleport(p, args[0]);
        }
        return true;
    }

    private boolean homesCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("This command can only be used in-game.");
            return true;
        }
        if (args.length == 0) { openHomes(p); return true; }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "create" -> createHome(p, args.length >= 2 ? args[1] : null);
            case "list" -> listHomes(p);
            case "settings" -> openSettings(p);
            case "help" -> sendHelp(p);
            case "info" -> {
                p.sendMessage(text("§b§lzHomes §8» §7Homes: §f" + homes.getOrDefault(p.getUniqueId(), Map.of()).size()
                    + "§7/§f" + (limit(p) == Integer.MAX_VALUE ? "∞" : limit(p))));
            }
            case "teleport" -> {
                if (args.length < 2) p.sendMessage(text("§cUsage: /homes teleport <name>"));
                else teleport(p, args[1]);
            }
            default -> {
                if (args.length == 1) teleport(p, args[0]);
                else sendHelp(p);
            }
        }
        return true;
    }

    private String createNextHome(Player p) {
        return createHome(p, null);
    }

    /** Creates a named home, or chooses the next free number when no name is supplied. */
    private String createHome(Player p, String requestedName) {
        if (!p.hasPermission("zhomes.use")) { msg(p, "no-permission"); return null; }
        Map<String, Location> map = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        if (map.size() >= limit(p)) { msg(p, "limit"); return null; }

        String name;
        if (requestedName == null || requestedName.isBlank()) {
            int number = 1;
            while (map.containsKey(Integer.toString(number))) number++;
            name = Integer.toString(number);
        } else {
            name = cleanName(requestedName);
            if (name == null) {
                p.sendMessage(text("§cInvalid home name. Use 1-24 letters, numbers, _ or -."));
                return null;
            }
            if (map.containsKey(name)) {
                p.sendMessage(text("§cA home named §f" + name + " §calready exists."));
                return null;
            }
        }

        map.put(name, p.getLocation().clone());
        saveHomes();
        msgHome(p, "set", name);
        return name;
    }

    private boolean deleteHomeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) { p.sendMessage(text("§cUsage: /delhome <name>")); return true; }
        Map<String, Location> map = homes.get(p.getUniqueId());
        if (map == null || map.remove(args[0].toLowerCase(Locale.ROOT)) == null) { msg(p, "not-found"); return true; }
        saveHomes(); msgHome(p, "deleted", args[0]); return true;
    }

    private boolean adminCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("zhomes.admin")) { sender.sendMessage(text("§cNo permission.")); return true; }
            reloadConfig(); sender.sendMessage(text("§azHomes configuration reloaded.")); return true;
        }
        sender.sendMessage(text("§bzHomes §7v1.0.3 §8| §7/zhomes reload"));
        return true;
    }

    private int limit(Player p) {
        if (p.hasPermission("zhomes.limit.unlimited")) return Integer.MAX_VALUE;
        ConfigurationSection section = getConfig().getConfigurationSection("homes.permission-limits");
        if (section != null) {
            List<String> permissions = new ArrayList<>(section.getKeys(false));
            permissions.sort((a, b) -> Integer.compare(section.getInt(b), section.getInt(a)));
            for (String permission : permissions) if (p.hasPermission(permission)) return section.getInt(permission);
        }
        return Math.max(0, getConfig().getInt("homes.default-limit", 5));
    }

    private void teleport(Player p, String rawName) {
        String name = rawName.toLowerCase(Locale.ROOT);
        Location loc = homes.getOrDefault(p.getUniqueId(), Map.of()).get(name);
        if (loc == null || loc.getWorld() == null) { msg(p, "not-found"); return; }
        if (confirmTeleport.contains(p.getUniqueId())) { openTeleportConfirm(p, name); return; }

        // Apply the same cooldown to command and GUI teleports.
        long now = System.currentTimeMillis();
        long cooldownMillis = getConfig().getLong("teleport.cooldown-seconds", 5L) * 1000L;
        long lastTeleport = teleportCooldowns.getOrDefault(p.getUniqueId(), 0L);
        long remaining = cooldownMillis - (now - lastTeleport);
        if (remaining > 0L) {
            long seconds = (remaining + 999L) / 1000L;
            p.sendMessage(text("§cPlease wait " + seconds + " second" + (seconds == 1 ? "" : "s") + " before teleporting again."));
            return;
        }
        if (!pendingTeleports.add(p.getUniqueId())) {
            p.sendMessage(text("§cA home teleport is already in progress."));
            return;
        }
        teleportCooldowns.put(p.getUniqueId(), now);
        p.closeInventory();
        int countdown = Math.max(1, getConfig().getInt("teleport.countdown-seconds", 5));
        final int[] remainingSeconds = {countdown};
        final int[] animationFrame = {0};
        p.sendTitle("§bTeleporting", "§fIn §e" + remainingSeconds[0] + " §fsec", 0, 20, 0);
        Bukkit.getScheduler().runTaskTimer(this, task -> {
            if (!p.isOnline()) {
                pendingTeleports.remove(p.getUniqueId());
                task.cancel();
                return;
            }
            if (remainingSeconds[0] <= 0) {
                task.cancel();
                p.sendActionBar(text("§aTeleporting now..."));
                p.teleportAsync(loc).thenAccept(success -> {
                    pendingTeleports.remove(p.getUniqueId());
                    if (success && p.isOnline()) p.sendMessage(text(message("teleport").replace("{home}", name)));
                });
                return;
            }
            String[] frames = {"§b◆§7◇◇", "§7◇§b◆§7◇", "§7◇◇§b◆", "§b◆§7◇◇"};
            String bar = frames[animationFrame[0]++ % frames.length];
            p.sendActionBar(text(bar + " §fTeleporting in §e" + remainingSeconds[0] + " §fsec"));
            p.sendTitle("§bTeleporting", "§fIn §e" + remainingSeconds[0] + " §fsec", 0, 20, 0);
            remainingSeconds[0]--;
        }, 0L, 20L);
    }

    /** Main menu: lapis opens saved homes; comparator opens settings. */
    private void openHomes(Player p) {
        MenuHolder holder = new MenuHolder("main", null);
        Inventory inv = Bukkit.createInventory(holder, 27, text(getConfig().getString("gui.main-title", "§8zHomes")));
        holder.inventory = inv;
        fill(inv);
        inv.setItem(getConfig().getInt("gui.main-homes-slot", 11), item(Material.LAPIS_LAZULI,
            "§bHomes", List.of("§7View all your saved homes.", "", "§aClick to open")));
        inv.setItem(getConfig().getInt("gui.main-settings-slot", 15), item(Material.COMPARATOR,
            "§eSettings", List.of("§7Personal home preferences", "", "§aClick to open")));
        p.openInventory(inv);
    }

    private String nextHomeName(Map<String, Location> playerHomes) {
        int number = 1;
        while (playerHomes.containsKey(Integer.toString(number))) number++;
        return Integer.toString(number);
    }

    private void listHomes(Player p) {
        Map<String, Location> playerHomes = homes.getOrDefault(p.getUniqueId(), Map.of());
        if (playerHomes.isEmpty()) { p.sendMessage(text("§7You have no saved homes. Use §f/homes create§7.")); return; }
        p.sendMessage(text("§b§lzHomes §8» §7Your homes:"));
        playerHomes.forEach((name, loc) -> p.sendMessage(text("§8• §b" + name + " §7- §f" +
            (loc.getWorld() == null ? "Unknown world" : loc.getWorld().getName()) + " §8| §7Use §f/home " + name)));
    }

    private void sendHelp(Player p) {
        p.sendMessage(text("§b§lzHomes §8» §7Commands"));
        for (String line : List.of("§f/homes §7- Open the home menu", "§f/homes create §7- Create the next numbered home",
            "§f/homes list §7- List saved homes", "§f/homes teleport <name> §7- Teleport to a home",
            "§f/homes settings §7- Personal settings", "§f/home <name> §7- Quick teleport")) p.sendMessage(text(line));
    }

    private void openSettings(Player p) {
        MenuHolder holder = new MenuHolder("settings", null);
        Inventory inv = Bukkit.createInventory(holder, 27, text("§8zHomes » Settings"));
        holder.inventory = inv;
        fill(inv);
        boolean enabled = confirmTeleport.contains(p.getUniqueId());
        inv.setItem(11, item(Material.LEVER, "§eTeleport Confirmation: " + (enabled ? "§aON" : "§cOFF"),
            List.of("§7When enabled, you'll confirm before", "§7teleporting from a home menu.", "", "§aClick to toggle")));
        inv.setItem(15, item(Material.BOOK, "§bCommand Guide", List.of("§f/homes list §7- List homes", "§f/homes create §7- Create home", "§f/home <name> §7- Quick teleport")));
        inv.setItem(22, item(Material.ARROW, "§fBack", List.of("§7Return to the main menu")));
        p.openInventory(inv);
    }

    private void openTeleportConfirm(Player p, String name) {
        MenuHolder holder = new MenuHolder("confirm-teleport", name);
        Inventory inv = Bukkit.createInventory(holder, 27, text("§8Teleport » " + name));
        holder.inventory = inv;
        fill(inv);
        inv.setItem(11, item(Material.ENDER_PEARL, "§aConfirm Teleport", List.of("§7Teleport to §f" + name)));
        inv.setItem(15, item(Material.RED_DYE, "§cCancel", List.of("§7Stay where you are")));
        p.openInventory(inv);
    }

    /** Shows every configured home slot as a bed: blue=saved, red=available, grey=locked. */
    private void openSavedHomes(Player p) { openSavedHomes(p, null); }

    private void openSavedHomes(Player p, String highlightedHome) {
        MenuHolder holder = new MenuHolder("homes", null);
        Inventory inv = Bukkit.createInventory(holder, 54, text(getConfig().getString("gui.homes-title", "§8zHomes » Your Homes")));
        holder.inventory = inv;
        fill(inv);

        List<Integer> slots = getConfig().getIntegerList("gui.home-slots");
        Map<String, Location> playerHomes = homes.getOrDefault(p.getUniqueId(), Map.of());
        List<Map.Entry<String, Location>> entries = new ArrayList<>(playerHomes.entrySet());
        int maxHomes = limit(p);
        int visibleSlots = Math.min(slots.size(), 54);

        for (int i = 0; i < visibleSlots; i++) {
            int slot = slots.get(i);
            if (slot < 0 || slot >= inv.getSize()) continue;
            if (i < entries.size()) {
                Map.Entry<String, Location> entry = entries.get(i);
                Location loc = entry.getValue();
                String worldName = loc.getWorld() == null ? "Unknown" : loc.getWorld().getName();
                boolean highlighted = entry.getKey().equals(highlightedHome);
                ItemStack bed = item(material(highlighted ? "gui.selected-home-material" : "gui.saved-home-material",
                        highlighted ? Material.LIME_BED : Material.BLUE_BED),
                    (highlighted ? "§a✦ " : "§b") + entry.getKey(), List.of("§7World: §f" + worldName,
                    "§7X: §f" + loc.getBlockX() + " §7Y: §f" + loc.getBlockY() + " §7Z: §f" + loc.getBlockZ(),
                    "", "§aLeft-click to teleport", "§eRight-click to manage"));
                if (highlighted) {
                    ItemMeta bedMeta = bed.getItemMeta();
                    bedMeta.addEnchant(Enchantment.UNBREAKING, 1, true);
                    bedMeta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
                    bed.setItemMeta(bedMeta);
                }
                inv.setItem(slot, bed);
                holder.slotHomes.put(slot, entry.getKey());
            } else if (i >= maxHomes) {
                inv.setItem(slot, item(material("gui.locked-material", Material.GRAY_BED),
                    "§8Locked Home Slot", List.of("§7Home slot locked by your limit.",
                    "§7Ask an admin about more slots.", "", "§cHome limit: " + (maxHomes == Integer.MAX_VALUE ? "Unlimited" : maxHomes))));
            } else {
                int remaining = Math.max(0, maxHomes == Integer.MAX_VALUE ? visibleSlots - entries.size() : maxHomes - entries.size());
                inv.setItem(slot, item(material("gui.create-home-material", Material.RED_BED),
                    "§cCreate Home", List.of("§7Save your current location.", "§7New home name: §f" + nextHomeName(playerHomes),
                    "", "§aClick to create", "§8Available slots: " + remaining)));
                holder.createSlots.add(slot);
            }
        }
        int backSlot = getConfig().getInt("gui.homes-back-slot", 49);
        if (backSlot >= 0 && backSlot < inv.getSize()) {
            inv.setItem(backSlot, item(material("gui.back-material", Material.ARROW),
                "§fBack", List.of("§7Return to the previous menu")));
        }
        p.openInventory(inv);
    }

    private void openManage(Player p, String name) {
        if (!homes.getOrDefault(p.getUniqueId(), Map.of()).containsKey(name)) { msg(p, "not-found"); openHomes(p); return; }
        MenuHolder holder = new MenuHolder("manage", name);
        Inventory inv = Bukkit.createInventory(holder, 27, text(getConfig().getString("gui.manage-title", "§8zHomes » Manage Home")));
        holder.inventory = inv;
        fill(inv);
        inv.setItem(getConfig().getInt("gui.teleport-slot", 10), item(material("gui.teleport-material", Material.ENDER_PEARL), "§bTeleport", List.of("§7Teleport to this home.", "", "§aClick to teleport")));
        inv.setItem(getConfig().getInt("gui.rename-slot", 12), item(material("gui.rename-material", Material.NAME_TAG), "§eRename Home", List.of("§7Change this home's name.", "", "§aClick to rename")));
        inv.setItem(getConfig().getInt("gui.icon-slot", 14), item(material("gui.icon-material", Material.CHEST), "§6Change Icon", List.of("§7Use the item in your main hand", "§7as this home's icon.", "", "§aClick to change")));
        inv.setItem(getConfig().getInt("gui.info-slot", 16), item(material("gui.info-material", Material.COMPASS), "§bHome Information", List.of("§7Home: §f" + name, "§7View saved coordinates.")));
        inv.setItem(getConfig().getInt("gui.delete-slot", 22), item(material("gui.delete-material", Material.LAVA_BUCKET), "§cDelete Home", List.of("§7Permanently delete this home.", "", "§cClick to continue")));
        inv.setItem(getConfig().getInt("gui.back-slot", 18), item(material("gui.back-material", Material.ARROW), "§fBack", List.of("§7Return to your saved homes")));
        p.openInventory(inv);
    }

    private void openDeleteConfirm(Player p, String name) {
        MenuHolder holder = new MenuHolder("confirm-delete", name);
        Inventory inv = Bukkit.createInventory(holder, 27, text("§8Confirm Delete » " + name));
        holder.inventory = inv;
        fill(inv);
        inv.setItem(11, item(Material.LIME_DYE, "§aConfirm Delete", List.of("§7Delete home §f" + name, "", "§aClick to confirm")));
        inv.setItem(15, item(Material.RED_DYE, "§cCancel", List.of("§7Keep this home", "", "§cClick to cancel")));
        p.openInventory(inv);
    }

    private void fill(Inventory inv) {
        ItemStack pane = item(material("gui.background-material", Material.GRAY_STAINED_GLASS_PANE), " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() != top) return;
        int slot = e.getSlot();

        if (holder.type.equals("main")) {
            if (slot == getConfig().getInt("gui.main-homes-slot", 11)) openSavedHomes(p);
            else if (slot == getConfig().getInt("gui.main-settings-slot", 15)) openSettings(p);
            return;
        } else if (holder.type.equals("settings")) {
            if (slot == 11) {
                if (!confirmTeleport.add(p.getUniqueId())) confirmTeleport.remove(p.getUniqueId());
                saveSettings();
                openSettings(p);
            } else if (slot == 22) openHomes(p);
            return;
        } else if (holder.type.equals("confirm-teleport")) {
            if (slot == 11) {
                String target = holder.home;
                confirmTeleport.remove(p.getUniqueId());
                teleport(p, target);
                confirmTeleport.add(p.getUniqueId());
            } else if (slot == 15) openSavedHomes(p);
            return;
        } else if (holder.type.equals("homes")) {
            String savedHome = holder.slotHomes.get(slot);
            if (savedHome != null) {
                if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) openManage(p, savedHome);
                else if (e.getClick().isLeftClick()) teleport(p, savedHome);
                return;
            }
            if (holder.createSlots.contains(slot) && e.getClick().isLeftClick()) {
                String created = createNextHome(p);
                if (created != null) openSavedHomes(p, created);
                return;
            }
            if (slot == getConfig().getInt("gui.homes-back-slot", 49)) {
                openHomes(p);
                return;
            }
        } else if (holder.type.equals("manage")) {
            String name = holder.home;
            if (slot == getConfig().getInt("gui.teleport-slot", 10)) teleport(p, name);
            else if (slot == getConfig().getInt("gui.rename-slot", 12)) ask(p, "rename", name);
            else if (slot == getConfig().getInt("gui.icon-slot", 14)) {
                msg(p, "icon-unavailable");
            } else if (slot == getConfig().getInt("gui.info-slot", 16)) {
                Location loc = homes.getOrDefault(p.getUniqueId(), Map.of()).get(name);
                if (loc != null && loc.getWorld() != null) p.sendMessage(text("§b" + name + " §7» §f" + loc.getWorld().getName() + " " + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()));
            } else if (slot == getConfig().getInt("gui.delete-slot", 22)) openDeleteConfirm(p, name);
            else if (slot == getConfig().getInt("gui.back-slot", 18)) openSavedHomes(p);
        } else if (holder.type.equals("confirm-delete")) {
            if (slot == 11) {
                Map<String, Location> map = homes.get(p.getUniqueId());
                if (map != null && map.remove(holder.home) != null) { saveHomes(); msgHome(p, "deleted", holder.home); }
                openHomes(p);
            } else if (slot == 15) openManage(p, holder.home);
        }
    }

    private void ask(Player p, String action, String oldName) {
        pending.put(p.getUniqueId(), new PendingInput(action, oldName));
        p.closeInventory();
        p.sendMessage(text("§b zHomes §8» §7Type the home name in chat. Type §ccancel §7to cancel."));
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent e) {
        PendingInput input = pending.remove(e.getPlayer().getUniqueId());
        if (input == null) return;
        e.setCancelled(true);
        String raw = e.getMessage().trim();
        String value = cleanName(raw);
        Bukkit.getScheduler().runTask(this, () -> {
            Player p = e.getPlayer();
            if (raw.equalsIgnoreCase("cancel")) { msg(p, "cancelled"); openHomes(p); return; }
            if (value == null) { p.sendMessage(text("§cInvalid name. Use letters, numbers, _ or - (1-24 characters).")); pending.put(p.getUniqueId(), input); return; }
            Map<String, Location> map = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
            if (input.action.equals("create")) {
                if (map.size() >= limit(p)) { msg(p, "limit"); openHomes(p); return; }
                if (map.containsKey(value)) { p.sendMessage(text("§cA home with that name already exists.")); openHomes(p); return; }
                map.put(value, p.getLocation().clone()); saveHomes(); msgHome(p, "set", value); openHomes(p);
            } else {
                Location loc = map.get(input.oldName);
                if (loc == null) { msg(p, "not-found"); openHomes(p); return; }
                if (!value.equals(input.oldName) && map.containsKey(value)) { p.sendMessage(text("§cThat name is already in use.")); openManage(p, input.oldName); return; }
                map.remove(input.oldName);
                map.put(value, loc);
                saveHomes();
                p.sendMessage(text("§aHome renamed to " + value + "."));
                openManage(p, value);
            }
        });
    }

    private String cleanName(String name) {
        return name != null && name.matches("[A-Za-z0-9_-]{1,24}") ? name.toLowerCase(Locale.ROOT) : null;
    }

    private Material material(String path, Material fallback) {
        Material m = Material.matchMaterial(getConfig().getString(path, fallback.name()));
        return m == null ? fallback : m;
    }

    private ItemStack item(Material material, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material);
        ItemMeta meta = stack.getItemMeta();
        meta.displayName(text(name));
        meta.lore(lore.stream().map(this::text).toList());
        stack.setItemMeta(meta);
        return stack;
    }

    private Component text(String value) { return LEGACY.deserialize(value == null ? "" : value); }
    private String message(String key) {
        return getConfig().getString("messages.prefix", "§b zHomes §8» §7") + getConfig().getString("messages." + key, "§cMessage missing: " + key);
    }
    private void msg(Player p, String key) { p.sendMessage(text(message(key))); }
    private void msgHome(Player p, String key, String home) { p.sendMessage(text(message(key).replace("{home}", home))); }

    private void loadSettings() {
        settingsFile = new File(getDataFolder(), "player-settings.yml");
        settingsYaml = YamlConfiguration.loadConfiguration(settingsFile);
        for (String id : settingsYaml.getStringList("teleport-confirmation")) {
            try { confirmTeleport.add(UUID.fromString(id)); }
            catch (IllegalArgumentException ignored) { getLogger().warning("Skipping invalid UUID in player-settings.yml: " + id); }
        }
    }

    private void saveSettings() {
        if (settingsYaml == null) settingsYaml = new YamlConfiguration();
        settingsYaml.set("teleport-confirmation", confirmTeleport.stream().map(UUID::toString).sorted().toList());
        try { settingsYaml.save(settingsFile); }
        catch (IOException ex) { getLogger().severe("Could not save player-settings.yml: " + ex.getMessage()); }
    }

    private void loadHomes() {
        homesYaml = YamlConfiguration.loadConfiguration(homesFile);
        homes.clear();
        ConfigurationSection players = homesYaml.getConfigurationSection("players");
        if (players == null) return;
        for (String uuidText : players.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(uuidText);
                ConfigurationSection section = players.getConfigurationSection(uuidText);
                Map<String, Location> map = new LinkedHashMap<>();
                if (section != null) for (String name : section.getKeys(false)) {
                    String path = "players." + uuidText + "." + name;
                    String worldName = homesYaml.getString(path + ".world");
                    World world = worldName == null ? null : Bukkit.getWorld(worldName);
                    if (world == null) continue;
                    map.put(name, new Location(world, homesYaml.getDouble(path + ".x"), homesYaml.getDouble(path + ".y"), homesYaml.getDouble(path + ".z"),
                        (float) homesYaml.getDouble(path + ".yaw"), (float) homesYaml.getDouble(path + ".pitch")));
                }
                homes.put(uuid, map);
            } catch (IllegalArgumentException ignored) { getLogger().warning("Skipping invalid player UUID in homes.yml: " + uuidText); }
        }
    }

    private void saveHomes() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Location>> player : homes.entrySet()) {
            for (Map.Entry<String, Location> entry : player.getValue().entrySet()) {
                String path = "players." + player.getKey() + "." + entry.getKey();
                Location loc = entry.getValue();
                if (loc.getWorld() == null) continue;
                yaml.set(path + ".world", loc.getWorld().getName());
                yaml.set(path + ".x", loc.getX()); yaml.set(path + ".y", loc.getY()); yaml.set(path + ".z", loc.getZ());
                yaml.set(path + ".yaw", loc.getYaw()); yaml.set(path + ".pitch", loc.getPitch());
            }
        }
        try { yaml.save(homesFile); }
        catch (IOException ex) { getLogger().severe("Could not save homes.yml: " + ex.getMessage()); }
    }

    private record PendingInput(String action, String oldName) { }

    private static final class MenuHolder implements InventoryHolder {
        private final String type;
        private final String home;
        private Inventory inventory;
        private final Map<Integer, String> slotHomes = new HashMap<>();
        private final Set<Integer> createSlots = new HashSet<>();
        private MenuHolder(String type, String home) { this.type = type; this.home = home; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
