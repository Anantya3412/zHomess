package com.zhomes;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Location;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class ZHomes extends JavaPlugin implements Listener {
    private final Map<UUID, Map<String, Location>> homes = new HashMap<>();
    private final Map<UUID, PendingInput> pending = new ConcurrentHashMap<>();
    private File homesFile;
    private YamlConfiguration homesYaml;
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacySection();

    @Override public void onEnable() {
        saveDefaultConfig();
        homesFile = new File(getDataFolder(), "homes.yml");
        if (!homesFile.exists()) try { getDataFolder().mkdirs(); homesFile.createNewFile(); } catch (IOException e) { getLogger().severe("Could not create homes.yml: " + e.getMessage()); }
        loadHomes();
        Bukkit.getPluginManager().registerEvents(this, this);
        Objects.requireNonNull(getCommand("home")).setExecutor(this::homeCommand);
        Objects.requireNonNull(getCommand("sethome")).setExecutor(this::setHomeCommand);
        Objects.requireNonNull(getCommand("delhome")).setExecutor(this::deleteHomeCommand);
        Objects.requireNonNull(getCommand("homes")).setExecutor((s,c,l,a) -> { if (!(s instanceof Player p)) return true; openHomes(p); return true; });
        Objects.requireNonNull(getCommand("zhomes")).setExecutor(this::adminCommand);
        getLogger().info("zHomes enabled.");
    }

    @Override public void onDisable() { saveHomes(); }

    private boolean setHomeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        String name = args.length == 0 ? "home" : cleanName(args[0]);
        if (name == null) { msg(p, "§cUse a home name containing letters, numbers, _ or -." ); return true; }
        Map<String, Location> map = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
        if (!map.containsKey(name) && map.size() >= limit(p)) { msg(p, "{limit}"); return true; }
        map.put(name, p.getLocation().clone()); saveHomes(); msgHome(p, "set", name); return true;
    }

    private boolean homeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) { openHomes(p); return true; }
        teleport(p, args[0]); return true;
    }

    private boolean deleteHomeCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player p)) return true;
        if (args.length == 0) { msg(p, "§cUsage: /delhome <name>"); return true; }
        Map<String, Location> map = homes.get(p.getUniqueId());
        if (map == null || map.remove(args[0].toLowerCase(Locale.ROOT)) == null) { msg(p, "{not-found}"); return true; }
        saveHomes(); msgHome(p, "deleted", args[0]); return true;
    }

    private boolean adminCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("zhomes.admin")) { sender.sendMessage("§cNo permission."); return true; }
            reloadConfig(); sender.sendMessage("§azHomes configuration reloaded."); return true;
        }
        sender.sendMessage("§bzHomes §7v1.0.0 §8| §7/zhomes reload"); return true;
    }

    private int limit(Player p) {
        ConfigurationSection section = getConfig().getConfigurationSection("homes.permission-limits");
        if (section != null) for (String permission : section.getKeys(false)) if (p.hasPermission(permission)) return section.getInt(permission);
        return getConfig().getInt("homes.default-limit", 3);
    }

    private void teleport(Player p, String name) {
        Map<String, Location> map = homes.get(p.getUniqueId());
        Location loc = map == null ? null : map.get(name.toLowerCase(Locale.ROOT));
        if (loc == null || loc.getWorld() == null) { msg(p, "{not-found}"); return; }
        p.closeInventory(); p.teleportAsync(loc).thenAccept(ok -> { if (ok) p.sendMessage(text(message("teleport").replace("{home}", name))); });
    }

    private void openHomes(Player p) {
        MenuHolder holder = new MenuHolder("homes", null);
        Inventory inv = Bukkit.createInventory(holder, 54, text(getConfig().getString("gui.homes-title", "§8zHomes » Homes")));
        holder.inventory = inv; fill(inv);
        List<Integer> slots = getConfig().getIntegerList("gui.home-slots");
        Map<String, Location> map = homes.getOrDefault(p.getUniqueId(), Map.of());
        int i = 0;
        for (Map.Entry<String, Location> entry : map.entrySet()) {
            if (i >= slots.size()) break;
            ItemStack bed = item(material("gui.saved-home-material", Material.BLUE_BED), "§b" + entry.getKey(), List.of("§7World: §f" + entry.getValue().getWorld().getName(), "§7X: §f" + entry.getValue().getBlockX() + " §7Y: §f" + entry.getValue().getBlockY() + " §7Z: §f" + entry.getValue().getBlockZ(), "", "§aLeft-click to teleport", "§eRight-click to manage"));
            inv.setItem(slots.get(i++), bed);
        }
        int createSlot = getConfig().getInt("gui.create-slot", 49);
        inv.setItem(createSlot, item(material("gui.create-material", Material.RED_BED), "§eCreate New Home", List.of("§7Save your current location", "§7as a new home.", "", "§aClick to create")));
        p.openInventory(inv);
    }

    private void openManage(Player p, String name) {
        MenuHolder holder = new MenuHolder("manage", name);
        Inventory inv = Bukkit.createInventory(holder, 54, text(getConfig().getString("gui.manage-title", "§8zHomes » Manage Home")));
        holder.inventory = inv; fill(inv);
        inv.setItem(getConfig().getInt("gui.teleport-slot", 11), item(material("gui.teleport-material", Material.ENDER_PEARL), "§bTeleport", List.of("§7Teleport to this home.", "", "§aClick to teleport")));
        inv.setItem(getConfig().getInt("gui.rename-slot", 13), item(material("gui.rename-material", Material.NAME_TAG), "§eRename Home", List.of("§7Change this home's name.", "", "§aClick to rename")));
        inv.setItem(getConfig().getInt("gui.icon-slot", 15), item(material("gui.icon-material", Material.CHEST), "§6Change Icon", List.of("§7Set the icon to the item", "§7in your main hand.", "", "§aClick to change")));
        inv.setItem(getConfig().getInt("gui.info-slot", 22), item(material("gui.info-material", Material.COMPASS), "§bHome Information", List.of("§7Home: §f" + name, "§7View your home details")));
        inv.setItem(getConfig().getInt("gui.delete-slot", 31), item(material("gui.delete-material", Material.LAPIS_LAZULI), "§cDelete Home", List.of("§7Permanently delete this home.", "", "§cClick to confirm")));
        inv.setItem(getConfig().getInt("gui.back-slot", 45), item(material("gui.back-material", Material.ARROW), "§fBack", List.of("§7Return to your homes")));
        p.openInventory(inv);
    }

    private void fill(Inventory inv) {
        ItemStack pane = item(material("gui.background-material", Material.GRAY_STAINED_GLASS_PANE), " ", List.of());
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, pane);
    }

    @EventHandler public void onInventoryClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p) || !(e.getInventory().getHolder() instanceof MenuHolder holder)) return;
        e.setCancelled(true);
        if (e.getClickedInventory() == null || e.getClickedInventory() != e.getInventory()) return;
        int slot = e.getSlot();
        if (holder.type.equals("homes")) {
            if (slot == getConfig().getInt("gui.create-slot", 49)) {
                if (homes.getOrDefault(p.getUniqueId(), Map.of()).size() >= limit(p)) { msg(p, "{limit}"); return; }
                ask(p, "create", null); return;
            }
            ItemStack clicked = e.getCurrentItem();
            if (clicked != null && clicked.getType().name().endsWith("_BED") && clicked.hasItemMeta()) {
                String name = LEGACY.serialize(clicked.getItemMeta().displayName()).replace("§b", "");
                if (e.isRightClick()) openManage(p, name); else teleport(p, name);
            }
        } else if (holder.type.equals("manage")) {
            String name = holder.home;
            if (slot == getConfig().getInt("gui.teleport-slot", 11)) teleport(p, name);
            else if (slot == getConfig().getInt("gui.rename-slot", 13)) ask(p, "rename", name);
            else if (slot == getConfig().getInt("gui.icon-slot", 15)) { msg(p, "§7The home icon is currently represented by its bed. Custom icon storage will be added in a future update."); }
            else if (slot == getConfig().getInt("gui.info-slot", 22)) { Location l = homes.getOrDefault(p.getUniqueId(), Map.of()).get(name); if (l != null) msg(p, "§b" + name + " §7» §f" + l.getWorld().getName() + " " + l.getBlockX() + ", " + l.getBlockY() + ", " + l.getBlockZ()); }
            else if (slot == getConfig().getInt("gui.delete-slot", 31)) { Map<String, Location> map = homes.get(p.getUniqueId()); if (map != null) map.remove(name); saveHomes(); msgHome(p, "deleted", name); openHomes(p); }
            else if (slot == getConfig().getInt("gui.back-slot", 45)) openHomes(p);
        }
    }

    private void ask(Player p, String action, String oldName) {
        pending.put(p.getUniqueId(), new PendingInput(action, oldName)); p.closeInventory();
        p.sendMessage(text("§b zHomes §8» §7Type the home name in chat. Type §ccancel §7to cancel."));
    }

    @EventHandler public void onChat(AsyncPlayerChatEvent e) {
        PendingInput input = pending.remove(e.getPlayer().getUniqueId()); if (input == null) return;
        e.setCancelled(true); String value = cleanName(e.getMessage().trim());
        Bukkit.getScheduler().runTask(this, () -> {
            Player p = e.getPlayer();
            if (e.getMessage().equalsIgnoreCase("cancel")) { msg(p, "§7Cancelled."); openHomes(p); return; }
            if (value == null) { msg(p, "§cInvalid name. Use letters, numbers, _ or -. Try again."); pending.put(p.getUniqueId(), input); return; }
            Map<String, Location> map = homes.computeIfAbsent(p.getUniqueId(), k -> new LinkedHashMap<>());
            if (input.action.equals("create")) {
                if (map.size() >= limit(p)) { msg(p, "{limit}"); openHomes(p); return; }
                if (map.containsKey(value)) { msg(p, "§cA home with that name already exists."); openHomes(p); return; }
                map.put(value, p.getLocation().clone()); saveHomes(); msgHome(p, "set", value); openHomes(p);
            } else {
                Location loc = map.remove(input.oldName);
                if (loc == null) { msg(p, "{not-found}"); openHomes(p); return; }
                if (map.containsKey(value)) { map.put(input.oldName, loc); msg(p, "§cThat name is already in use."); openHomes(p); return; }
                map.put(value, loc); saveHomes(); msg(p, "§aHome renamed to " + value + "."); openManage(p, value);
            }
        });
    }

    private String cleanName(String name) { return name.matches("[A-Za-z0-9_-]{1,24}") ? name.toLowerCase(Locale.ROOT) : null; }
    private Material material(String path, Material fallback) { Material m = Material.matchMaterial(getConfig().getString(path, fallback.name())); return m == null ? fallback : m; }
    private ItemStack item(Material material, String name, List<String> lore) { ItemStack stack = new ItemStack(material); ItemMeta meta = stack.getItemMeta(); meta.displayName(text(name)); meta.lore(lore.stream().map(this::text).toList()); stack.setItemMeta(meta); return stack; }
    private Component text(String value) { return LEGACY.deserialize(value == null ? "" : value); }
    private String message(String key) { return getConfig().getString("messages.prefix", "§b zHomes §8» §7") + getConfig().getString("messages." + key, "§cMessage missing: " + key); }
    private void msg(Player p, String key) {
        if (key.startsWith("§")) { p.sendMessage(text(key)); return; }
        String normalized = key.startsWith("{") && key.endsWith("}") ? key.substring(1, key.length() - 1) : key;
        p.sendMessage(text(message(normalized)));
    }
    private void msgHome(Player p, String key, String home) { p.sendMessage(text(message(key).replace("{home}", home))); }

    private void loadHomes() {
        homesYaml = YamlConfiguration.loadConfiguration(homesFile); homes.clear();
        ConfigurationSection players = homesYaml.getConfigurationSection("players"); if (players == null) return;
        for (String uuidText : players.getKeys(false)) try {
            UUID uuid = UUID.fromString(uuidText); ConfigurationSection section = players.getConfigurationSection(uuidText); Map<String, Location> map = new LinkedHashMap<>();
            if (section != null) for (String name : section.getKeys(false)) {
                String path = uuidText + "." + name; String worldName = homesYaml.getString("players." + path + ".world"); World world = Bukkit.getWorld(worldName == null ? "" : worldName);
                if (world == null) continue;
                map.put(name, new Location(world, homesYaml.getDouble("players." + path + ".x"), homesYaml.getDouble("players." + path + ".y"), homesYaml.getDouble("players." + path + ".z"), (float) homesYaml.getDouble("players." + path + ".yaw"), (float) homesYaml.getDouble("players." + path + ".pitch")));
            }
            homes.put(uuid, map);
        } catch (IllegalArgumentException ignored) { }
    }

    private void saveHomes() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Location>> player : homes.entrySet()) for (Map.Entry<String, Location> entry : player.getValue().entrySet()) {
            String path = "players." + player.getKey() + "." + entry.getKey(); Location l = entry.getValue();
            yaml.set(path + ".world", l.getWorld().getName()); yaml.set(path + ".x", l.getX()); yaml.set(path + ".y", l.getY()); yaml.set(path + ".z", l.getZ()); yaml.set(path + ".yaw", l.getYaw()); yaml.set(path + ".pitch", l.getPitch());
        }
        try { yaml.save(homesFile); } catch (IOException e) { getLogger().severe("Could not save homes: " + e.getMessage()); }
    }

    private record PendingInput(String action, String oldName) { }
    private static final class MenuHolder implements InventoryHolder {
        private final String type; private final String home; private Inventory inventory;
        private MenuHolder(String type, String home) { this.type = type; this.home = home; }
        @Override public Inventory getInventory() { return inventory; }
    }
}
