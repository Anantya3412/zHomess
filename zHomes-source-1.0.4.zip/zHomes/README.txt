zHomes 1.0.3

Requirements:
- Paper 1.21.11 (or compatible Paper 1.21.x server)
- Java 21

Commands:
- /home <name> - teleport to a saved home; /home opens the main GUI.
- /homes - open the main GUI.
- /homes create - create the next available numbered home (1, 2, 3...).
- /homes list - list saved homes and their worlds.
- /homes teleport <name> - teleport to a saved home.
- /homes settings - open personal settings.
- /homes help - show the command guide.
- /homes info - show your home count and limit.
- /homes <name> - quick teleport to a saved home.
- /sethome [name] - create or update a named home.
- /delhome <name> - delete a home.
- /zhomes reload - reload configuration (admin).

GUI:
- Main menu: Lapis Lazuli opens saved homes; White Banner creates the next numbered home; Comparator opens settings.
- Saved-homes selector: Blue Bed = saved home (left-click teleport, right-click manage); Red Bed = create next numbered home; Gray Bed = locked slot.
- Home management includes teleport, rename, information, delete confirmation, and back navigation.
- Settings include a persistent teleport-confirmation toggle.

Tab completion:
- /home suggests all saved home names.
- /homes suggests create, list, settings, teleport, help, info, and saved home names.
- /homes teleport <tab> suggests saved home names.

Default home limit is 5. Configure limits and GUI slots in config.yml.
Homes are stored in plugins/zHomes/homes.yml. Player preferences are stored in plugins/zHomes/player-settings.yml.

Version 1.0.4 GUI update:
- Removed the Create New Home option from the main menu.
- Removed clickable create-home beds from the saved-homes menu.
- Added a Back arrow (default slot 49) to the saved-homes menu.
- Homes can still be created using /homes create or /sethome.
