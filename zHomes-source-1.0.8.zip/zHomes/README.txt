zHomes v1.0.8 source

Build with Java 21 and Maven:
  mvn clean package

Commands:
  /home                         Open the Homes GUI
  /home <name>                  Teleport to a saved home
  /home create [name]           Create a named home, or next numeric home
  /homes                        Open the Homes GUI
  /homes create [name]          Create a named home, or next numeric home
  /homes list                   List saved homes
  /homes settings               Open personal settings
  /homes teleport <name>        Teleport to a saved home
  /homes help                   Show help
  /homes info                   Show home count and limit

If a name is supplied, it is validated (1-24 letters, numbers, underscore, or hyphen)
and stored in lowercase. If omitted, the next available numeric name is selected:
1, 2, 3, and so on.

The plugin uses config.yml and homes.yml in its plugin data folder.
